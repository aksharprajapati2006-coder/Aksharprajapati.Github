# Akshar Prajapati Portfolio

## Files
- `index.html` — portfolio page
- `style.css` — responsive styling
- `assets/profile.jpg` — uploaded profile photo

## Publish with GitHub Pages
1. Create a GitHub repository.
2. Upload all files while keeping the `assets` folder.
3. Go to **Settings → Pages**.
4. Select **Deploy from a branch**, choose `main` and `/ (root)`.
5. Save and open the generated GitHub Pages URL.

GitHub Pages publishes static HTML/CSS/JS files from a repository.
